rootProject.name = "vertx-starter"
